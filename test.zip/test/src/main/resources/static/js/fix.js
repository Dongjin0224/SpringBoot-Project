$(document).ready(function(){
    $("#header").load("http://localhost:10007/header");
    $("#footer").load("http://localhost:10007/footer");
});